document.getElementById("registrationForm").addEventListener("submit", function(event) {
    event.preventDefault();

    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    // Simulate a POST request using Fetch API (you can replace this with a real API endpoint)
    fetch("https://jsonplaceholder.typicode.com/posts", {
        method: "POST",
        body: JSON.stringify({ name, email, password }),
        headers: {
            "Content-type": "application/json; charset=UTF-8"
        }
    })
    .then(response => response.json())
    .then(data => {
        // Store the registration data in an array or Local Storage (here, we use an array)
        const userData = { name, email, password };
        saveUserData(userData);

        // Redirect to a new page to display the data
        window.location.href = "data-list.html";
    });
});

function saveUserData(userData) {
    // You can store this data in an array or use Local Storage
    // In this example, we store it in an array
    let registrations = JSON.parse(localStorage.getItem("registrations")) || [];
    registrations.push(userData);
    localStorage.setItem("registrations", JSON.stringify(registrations));
}
